function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("black");
  fill("white");
  textSize(48);
  textAlign(CENTER, CENTER)
  
  let maximo = width;
  let minimo = 0;
  let palavra = "PedroHenrique3A";
  let quantidade = map(mouseX, 0, width, 1, palavra.length);
  let parcial = palavra.substring(0,quantidade);
  text(parcial,200,200);
  
//  if(mouseX < 50){
//    let palavra = "P";
//    text(palavra, 200, 200);
//  } else {
//    let palavra = "PedroHenrique3A";
//    text(palavra, 200, 200);
//  }
}
